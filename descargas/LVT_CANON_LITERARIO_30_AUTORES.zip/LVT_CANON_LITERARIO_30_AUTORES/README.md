﻿# PROTOCOLO DE INVESTIGACIÓN, ACOPIO FILOLÓGICO Y ARCHIVO PATRIMONIAL
## CANON DE 30 AUTORES FUNDAMENTALES
### Sociedad de Escritores «Letras y Voces de Tabasco, A.C.» (LVT)


---


## 1. PRESENTACIÓN Y ALCANCE INSTITUCIONAL
El presente repositorio constituye el fondo documental, crítico, biográfico, antológico e iconográfico canónico de 30 autores fundamentales (Tabasqueños, Mexicanos y Universales), desarrollado bajo la encomienda y tutela de la Sociedad de Escritores «Letras y Voces de Tabasco, A.C.» (LVT).


El corpus está estructurado con el máximo rigor académico, filológico y hemerográfico, satisfaciendo los criterios de ediciones críticas universitarias (UNAM, El Colegio de México, Fondo de Cultura Económica, El Colegio Nacional y la Academia Mexicana de la Lengua). Cada pliego autoral comprende entre 4,500 y 6,000 palabras de prosa crítica y selección textual íntegra (tiempo de lectura estimado de 25 a 30 minutos por autor).


---


## 2. ESTRUCTURA Y TAXONOMÍA DEL REPOSITORIO


LVT_CANON_LITERARIO_30_AUTORES/
├── README.md                            <- Protocolo rector y control de calidad metodológico
├── INVENTARIO_GENERAL_CANON.json        <- Matriz consolidada de metadatos de los 30 autores
├── 01_TABASQUENOS/                      <- 12 Escritores Ilustres de Tabasco
├── 02_MEXICANOS/                        <- 10 Autores Nacionales Fundamentales
└── 03_UNIVERSALES/                      <- 8 Autores Universales Esenciales en Español


---


## 3. ESPECIFICACIÓN DE CONTENIDOS POR AUTOR
Cada unidad documental se compone de:
1. dossier_canonico.md: Despliegue exhaustivo en 6 secciones (Ficha técnica; Ensayo biográfico-crítico de 1,500-2,000 palabras; Antología íntegra de 2,500-3,500 palabras; 5 Citas célebres verificadas con fuente de edición; Bibliografía cronológica; Fuentes archivísticas y hemerográficas).
2. metadata.json: Ficha descriptiva estructurada para indexación catalográfica y sistemas bibliotecarios digitales.
3. Archivos iconográficos históricos: retrato_archivo.jpg y portadas de primeras ediciones.


---


## 4. REGLA DE ORO FILOLÓGICA
- Cero alucinaciones o síntesis abreviadas: Todos los textos corresponden a ediciones críticas fijadas.
- Cero imágenes sintéticas por IA: Todos los retratos proceden de fototecas públicas históricas.